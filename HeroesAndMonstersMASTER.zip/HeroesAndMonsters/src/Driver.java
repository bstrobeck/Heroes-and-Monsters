//Brandtly Strobeck
//CSCD 211
//This program will have the user choose from 3 predeterimed classes, and they will fight to the death against a randomly generated monster.

import java.util.*;
public class Driver
{
	static Random rng = new Random();
	static Scanner kb = new Scanner(System.in);
	private static Hero hero;
	private static Monster monster;
	
	public static void main(String[] args)
	{
		 Scanner kb = new Scanner(System.in);
		do
		{
			System.out.println("+========================================+");
			System.out.println("|Pick your class: ");
			System.out.println("|1. The Mighty Warrior " );
			System.out.println("|2. The Wicked Sorceress ");
			System.out.println("|3. The Cunning Thief " );
			System.out.println("+========================================+");
			
			int choice = kb.nextInt();
			
			while(choice < 1 || choice > 3)//doing a little data validation, to make sure the user chooses the correct option.
			{
				System.out.println("+========================================+");
				System.out.println("|Incorrect choice, please choose again");
				System.out.println("|Pick your class: ");
				System.out.println("|1. The Mighty Warrior " );
				System.out.println("|2. The Wicked Sorceress ");
				System.out.println("|3. The Cunning Thief " );
				System.out.println("+========================================+");
				choice = kb.nextInt();	
			}
			
			switch(choice)
			{
				case 1:
					hero = new Warrior();
					break;
				
				case 2:
					hero = new Sorceress();
					break;
				
				case 3:
					hero = new Thief();
			}
			
			int random = rng.nextInt(3);
			switch(random)// i had originally planned to choose the monster by having them live in an array, and randomly loop throug the array, but i couldn't figure it out and ran out of time :(
			{//anyways this will accept a random int between 0(inclusive) and 3(exclusive) to pick the monster to fight.
				case 0:
					monster = new Skeleton();
					break;
					
				case 1:
					monster = new Ogre();
					break;
					
				case 2:
					monster = new Gremlin();
					break;
			}	
			System.out.println("\n" + monster.getName() + " joins the fray!");
		
		
		while(hero.getHealth() > 0 && monster.getHealth() > 0)//this will basically be the block that runs the game. every loop it will doublecheck the players and monster's health to see if the game needs to continue.
		{
			hero.numberOfTurns(monster);
			if(hero.getHealth() < 0 || monster.getHealth() < 0)
			{
				if(hero.getHealth() <= 0)
				{
					System.out.println("YOU DIED");//if the hero dies
				}
				else
				{
					System.out.println("The monster is dead!");//if the monster dies
				}
				break;
			}
			else
			{
				monster.attack(hero);
			}
		}
			
		
		System.out.println("+========================================+");//asks if they want to play again
		System.out.println("|G A M E O V E R");
		System.out.println("|Play again?");
		System.out.println("|1. YES \n2. NO");
		System.out.println("+========================================+");
		
		int option = kb.nextInt();
	
		if(option == 2)
		{
			System.out.println("MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM");//shout out to http://www.chris.com/ascii/index.php?art=people/skeletons where i got this ascii art from ^^
			System.out.println("MMMMMMMMMMMM        MMMMMMMMMMMM");
			System.out.println("MMMMMMMMMM            MMMMMMMMMM");
			System.out.println("MMMMMMMMM              MMMMMMMMM");
			System.out.println("MMMMMMMM                MMMMMMMM");
			System.out.println("MMMMMMM                 MMMMMMMM");
			System.out.println("MMMMMMM                  MMMMMMM");
			System.out.println("MMMMMMM                  MMMMMMM");
			System.out.println("MMMMMMM    MMM    MMM    MMMMMMM");
			System.out.println("MMMMMMM   MMMMM   MMMM   MMMMMMM");
			System.out.println("MMMMMMM   MMMMM   MMMM   MMMMMMM");
			System.out.println("MMMMMMMM   MMMM M MMMM  MMMMMMMM");
			System.out.println("MMVKMMMM        M        MMMMMMM");
			System.out.println("MMMMMMMM       MMM      MMMMMMMM");
			System.out.println("MMMMMMMMMMMM   MMM  MMMMMMMMMMMM");
			System.out.println("MMMMMMMMMM MM       M  MMMMMMMMM");
			System.out.println("MMMMMMMMMM  M M M M M MMMMMMMMMM");
			System.out.println("MMMM  MMMMM MMMMMMMMM MMMMM   MM");
			System.out.println("MMM    MMMM M MMMMM M MMMM    MM");
			System.out.println("MMM    MMMM   M M M  MMMMM   MMM");
			System.out.println("MMMM    MMMM         MMM      MM");
			System.out.println("MMM       MMMM     MMMM       MM");
			System.out.println("MMM         MMMMMMMM      M  MMM");
			System.out.println("MMMM  MMM      MMM      MMMMMMMM");
			System.out.println("MMMMMMMMMMM  MM       MMMMMMM  M");
			System.out.println("MMM  MMMMMMM       MMMMMMMMM   M");
			System.out.println("MM    MMM        MM            M");
			System.out.println("MM            MMMM            MM");
			System.out.println("MMM        MMMMMMMMMMMMM       M");
			System.out.println("MM      MMMMMMMMMMMMMMMMMMM    M");
			System.out.println("MMM   MMMMMMMMMMMMMMMMMMMMMM   M");//btw yes, i did spent a considerable amount of time formating this. thank you for asking!
			System.out.println("SEE YOU NEXT TIME LOSER!");
			break;
		}
		else
		{
			System.out.println("You have chosen to play again");
		}
		
	}//do
		
	while (true);//basically the whole thing is wrapped in this while loop, that keeps the game running as longas the player would like
		
	}//main
		
}//class
