import java.util.Random;
public class Sorceress extends Hero
{
	//special stats exclusive to the sorcerers
	private int healMin;
	private int healMax;
	Random rng = new Random();
	
	public Sorceress()//ctor
	{
		super("", 75, 5, 25, 45, .7, .3);
		this.healMin = 30;
		this.healMax = 50;
		
	}
	
	public int getHealMin()//gets and sets follow
	{
		return healMin;
	}

	public void setHealMin(int healMin)
	{
		this.healMin = healMin;
	}

	public int getHealMax()
	{
		return healMax;
	}

	public void setHealMax(int healMax)
	{
		this.healMax = healMax;
	}

	@Override
	public void specialSkill(DungeonCharacter other)//special skill for sorceress that heals her
	{
		int heal = rng.nextInt((healMax - healMin)  + 1) + healMin;
		this.health += heal;
		System.out.println(name + " healed herself for " + heal + "\n" + name + " now has " + health + " health!");	
	}	
}
