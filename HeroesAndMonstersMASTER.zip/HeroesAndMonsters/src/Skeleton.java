
public class Skeleton extends Monster
{

	public Skeleton()
	{
		super("Mr. Skeltal the Skeleton", 100, 3, 30, 50, .8, .3, 30, 50);
	}

}
