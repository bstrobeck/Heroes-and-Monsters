import java.util.Random;
import java.util.Scanner;
public abstract class Hero extends DungeonCharacter
{
	protected double block;
	protected int turns;
	Random rng = new Random();
	Scanner kb = new Scanner(System.in);
	
	
	public Hero(String name, int health, int speed, int minDamage, int maxDamage, double toHit, double block)//ctor for a hero, it borrows from its parent class, in that it accepts a name, health, speed, etc. but also adds on the block feature.
	{
		super("", health, speed, minDamage, maxDamage, toHit);
		this.block = block;
		this.name = inputName();//calls the inputName method to get the name
	
	}

	public void setBlock(double block)//this should be checked after the Monster has attacked and hit points are about to be removed from the Hero
	{
		this.block = block;
	}
	
	public double getBlock()
	{
		return block;
	}
	
	@Override
	public String toString()
	{
		return super.toString() + " Chance to block " + block;
	}
	
	public void numberOfTurns(DungeonCharacter that)//using that will probably fuck something up later bear in mind
	{
		
		if(this.speed / that.speed > 0);
		{
			turns = this.speed / that.speed;
			
			try
			{
				while(turns > 0)
				{
					//System.out.println(turns + " left in round");
				int choice = displayMenu(kb);
				if(!(choice == 1 ||choice == 2 || choice == 3))
				{
					System.out.println("Invalid option");
				}
					if(this.getHealth() <= 0 || that.getHealth() <= 0)
					{
						break;
					}
					turns--;
					switch(choice)
					{
						case 1:
							this.attack(that);
							break;
							
						case 2:
							this.specialSkill(that);
							break;
							
						case 3:
							System.out.println("Leaving Heroe v. Monster...");
							break;
								
					}
			}
		}
			catch (Exception e)
			{
				System.out.println("Invalid option, please choose again.");
			}
		}
	}
	public int displayMenu(Scanner kb)//when it's the heroe's turn, displays their options, as well as how many turns are remaining
	{
		System.out.println("\n+========================================+");
		System.out.println("|Player Actions: 						  ");
		System.out.println("|\t1. Attack! 							   ");
		System.out.println("|\t2. " + name + "'s Special Skill! 	   ");
		System.out.println("|\t3. Quit 								   ");
		System.out.println("| " + turns + " turns remaining...         ");
		System.out.println("+========================================+");
		int choice = kb.nextInt();
		
		return choice;
	}
	
	public String inputName()//this will collect the player's name
	{
		System.out.print("Enter your hero's name: ");
		name = kb.nextLine();
		return name;
	}
	
	//@Override
	public void attack(DungeonCharacter other)
	{
		
				double chance = rng.nextDouble();
				if(chance <= toHit)
				{
					damageCalculator(other);	
				}
				else
				{
					System.out.println("\n" + name + " missed their attack!");
				}
	}
	
	public void damageCalculator(DungeonCharacter other)//once the Monster hierarchy is established, need to come back through and change things maybe? idk
	{
		
		int damage = rng.nextInt((maxDamage - minDamage) + 1) + minDamage;
		
		double random = rng.nextDouble();
		if(random <= block)
		{
			System.out.println("\n" + name + " blocked the attack!");
			
		}
		else
		{
			other.health -= damage;
			System.out.println("\n" + name + "'s attack hit and did " + damage + " damage!");
			
			if(other.health <= 0)
			{
				System.out.println(other.name + " has been slain!");	
			}
			else
			{
				System.out.println(other.name + " has " + other.health + " health remaining!");
			}
		}
	}
	
	public abstract void specialSkill(DungeonCharacter other);
	
}//class
