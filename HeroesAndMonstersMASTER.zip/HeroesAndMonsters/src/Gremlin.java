
public class Gremlin extends Monster
{

	public Gremlin()
	{
		super("Gary the Gremlin", 70, 5, 15, 30, .8, .4, 15, 40);
	}

}
