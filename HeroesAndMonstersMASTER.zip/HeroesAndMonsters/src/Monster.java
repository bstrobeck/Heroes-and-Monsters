//import java.util.Random;
public class Monster extends DungeonCharacter
{
	protected double healChance;
	protected int healMin;
	protected int healMax;
	
	public Monster(String name, int health, int speed, int minDamage, int maxDamage, double toHit, double healChance, int healMin, int healMax)//ctor
	{
		super(name, health, speed, minDamage, maxDamage, toHit);
		this.healChance = healChance;
		this.healMin = healMin;
		this.healMax = healMax;	
	}

	public double getHealChance()//sets and gets follow
	{
		return healChance;
	}

	public void setHealChance(double healChance)
	{
		this.healChance = healChance;
	}

	public int getHealMin()
	{
		return healMin;
	}

	public void setHealMin(int healMin)
	{
		this.healMin = healMin;
	}

	public int getHealMax()
	{
		return healMax;
	}

	public void setHealMax(int healMax)
	{
		this.healMax = healMax;
	}
	
	public String getName()
	{
		return name;
	}
	public void heal()
	{
		double chance;
		chance = rng.nextDouble();
		if(chance <= healChance)
		{
			int heal = rng.nextInt((healMax - healMin) + 1)+ healMin;
			health += heal;
			System.out.println(name + " has healed itself for " + heal + " health");
			System.out.println("They now have " + health + " health");
		}
		else
			if(this.health <= 0)
			{
				System.out.println("Monster is dead");
			}
			else
			
			{
			System.out.println(name + " failed to heal itself");
			}
	}
	
	
	

}
