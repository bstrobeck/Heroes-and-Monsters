
public class Ogre extends Monster
{

	public Ogre()
	{
		super("Trump the Ogre", 200, 2, 30, 60, .6, .1, 30, 60);
		
	}

}
