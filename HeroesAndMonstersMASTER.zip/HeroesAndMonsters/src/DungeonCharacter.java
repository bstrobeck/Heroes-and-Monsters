import java.util.*;
public  abstract class DungeonCharacter

{
	//member variables
	protected String name;
	protected int health;
	protected int speed;
	protected int minDamage;
	protected int maxDamage;
	protected double toHit;
	protected Random rng = new Random();
	protected int damage;
	protected Scanner kb;
	
	public DungeonCharacter(String name, int health, int speed, int minDamage, int maxDamage, double toHit)//constructor to initialize the variables
	{
		this.name = name;
		this.health = health;
		this.speed = speed;
		this.minDamage = minDamage;
		this.maxDamage = maxDamage;
		this.toHit = toHit;
	}

	public String getName()//sets and gets follow
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

	public int getHealth()
	{
		return health;
	}

	public void setHealth(int health)
	{
		this.health = health;
	}

	public int getSpeed()
	{
		return speed;
	}

	public void setSpeed(int speed)
	{
		this.speed = speed;
	}

	public int getMinDamage()
	{
		return minDamage;
	}

	public void setMinDamage(int minDamage)
	{
		this.minDamage = minDamage;
	}
	
	public int getMaxDamage()
	{
		return maxDamage;
	}
	
	public void setMaxDamage(int maxDamage)
	{
		this.maxDamage = maxDamage;
	}

	public double getToHit()
	{
		return toHit;
	}

	public void setToHit(double toHit)
	{
		this.toHit = toHit;
	}
	
	@Override
	public String toString()
	{
		return "You have created a DungeonCharacter: " + "Name: " + getName() + " Health: " + getHealth() + " Attack speed: " + getSpeed() + " Minimum Damage: " + getMinDamage() + " Maximum Damage: " + getMaxDamage() + " Chance to hit: " + getToHit();	
	}
	
	public void attack(DungeonCharacter other)
	{
		//this method measures whether or not the attack will be successful, and how much damage will be done.
		double chance = rng.nextDouble();
		if(chance <= toHit)
		{
			damage = rng.nextInt((maxDamage - minDamage) + 1) + minDamage;
								
			System.out.println(name + "'s attack hit and did " + damage + " damage!");
			
			other.health -= damage;
			System.out.println(other.name + " has " + other.health + " health remaining!");	
		}
		else
		{
			System.out.println(name + "'s missed their attack!");
		}
	}	
}//class
