import java.util.Random;

public class Thief extends Hero
{
	private double surpriseHit;
	Random rng = new Random();
	
	public Thief()//ctor for thief
	{
		super("", 75, 6, 20, 45, .8, .4);
		this.surpriseHit = .4;
	}
	public double getSurpriseHit()//sets and gets for Thief specific stats
	{
		return surpriseHit;
	}
	public void setSurpriseHit(double surpriseHit)
	{
		this.surpriseHit = surpriseHit;
	}
	
	@Override
	public void specialSkill(DungeonCharacter other)
	{
		double chance = rng.nextDouble();
		
		if(chance <= surpriseHit)
		{
			System.out.println(name + " snuck up from behind and struck!");
			damageCalculator(other);
		}
		else
		{
			System.out.println(name + "'s Sneak Attack missed!");
		}
		
	}	
}
