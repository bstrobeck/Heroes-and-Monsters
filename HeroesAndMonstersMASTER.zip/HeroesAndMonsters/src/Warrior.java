import java.util.*;

public class Warrior extends Hero
{
	//these are attributes that are specific to the warrior class's Special Skill
	private double specialHit;
	private int specialMin;
	private int specialMax;
	Random rng = new Random();
	
	public Warrior()//ctor for the Warrior with all his specific stats
	{
		super("", 125, 4, 35, 60, .8, .2);//these are the specific stats for the warrior.
	
		this.specialHit = .4;
		this.specialMin = 75;
		this.specialMax = 175;
	}
	
	public void setSpecialHit(double specialHit)//sets and gets follow
	{
		this.specialHit = specialHit;
	}
	
	public double getSpecialHit()
	{
		return specialHit;
	}
	
	public void setSpecialMin(int specialMin)
	{
		this.specialMin = specialMin;
	}
	
	public int getSpecialMin()
	{
		return specialMin;
	}
	
	public void setSpecialMax(int specialMax)
	{
		this.specialMax = specialMax;
	}
	
	public int getSpecialMax()
	{
		return specialMax;
	}

	@Override
	public void specialSkill(DungeonCharacter other)//this will be the special skill attack for the warrior 
	{
		double chance = rng.nextDouble();
		int damage = rng.nextInt((specialMax - specialMin) +1 ) + specialMin;//calculate the damage bewtween the min and max
		
		if(chance <= specialHit)
		{
			System.out.println("Crushing Blows missed!");
		}
		else
		{
			other.health -= damage;
			System.out.println(name + " did " + damage + " damage with it's Crushing Blows!");
			
			if(other.health <= 0)
			{
				System.out.println(other.name + " has been defeated!");
				//resetGame(); see Hero class
			}
			else
			{
				System.out.println(other.name + " has " + other.health + " remaining");
			}
		}
		
		
	}
	
	
}//class
